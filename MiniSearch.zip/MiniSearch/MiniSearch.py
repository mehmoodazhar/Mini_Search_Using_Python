from tkinter import *
import wikipedia
#Main Window Settings starts
root = Tk()
root.title("AK SEARCH ENGINE | SEARCH ANY INFORMATION")
root.configure(bg="#24252a")
root.minsize(width="1000",height="1000")
#root.maxsize(width="1000",height="1000")
#Main Window Settings Ends here

word = Label(root)


#Button Function Starts Here
def getVal():
    global word
    word.destroy()
    User_typed_text = user_word.get()
    wiki_result = wikipedia.summary(User_typed_text,sentences=5)
    word = Label(Frame_3 ,text=wiki_result , wraplength=900,bg="#24252a",fg="#fff",font=("Arial Narrow",15),pady=5)
    word.pack()
    User_Search.delete(0,END)

#Button Functions Ends Here

#Background Image COnfiguration Starts

bg_img = PhotoImage(file="bg.png")
run_bg = Label(image= bg_img)
run_bg.pack()

#Background Image COnfiguration Ends here


#Search / Entry Widget starts From Here
Frame_1 = (root)

user_word = StringVar()
User_Search = Entry(textvariable=user_word,width=45,font=("Arial Narrow", 15, "bold"),bd=5,relief="sunken")
User_Search.pack(pady=10)

#Search / Entry Widget Ends here

# Frame_3 of Wikipedia Search Results Here

Frame_3 = (root)
Frame_3.configure()
# Frame_3 of Wikipedia Search Results Here

#Submit Button Code Starts
Frame_2 = (root)
Search_Button = Button(Frame_2,text="Search",command = getVal,width=30,pady=5,relief = "sunken",bg="#2574a9",fg="#fff",
                       font=("AGENCY FB", 15, "bold"))
Search_Button.pack()

#Submit Button Code Ends Here




root.mainloop()
#Window Settings ends here